 --1) Numero totale degli ordini
SELECT COUNT(*) AS NumeroTotaleOrdini
FROM Orders;

-- 2) Numero totale di clienti
SELECT COUNT(*) AS NumeroTotaleClienti
FROM Customers;

-- 3) Numero totale di clienti che abitano a Londra
SELECT COUNT(*) AS NumeroClientiLondra
FROM Customers
WHERE City = 'London';

-- 4) La media aritmetica del costo del trasporto di tutti gli ordini effettuati
SELECT AVG(Freight) AS MediaCostoTrasporto
FROM Orders;

-- 5) La media aritmetica del costo del trasporto dei soli ordini effettuati dal cliente �BOTTM�
SELECT AVG(Freight) AS MediaCostoTrasportoClienteBOTTM
FROM Orders
WHERE CustomerID = 'BOTTM';

-- 6) Totale delle spese di trasporto effettuate raggruppate per id cliente
SELECT CustomerID, SUM(Freight) AS TotaleSpeseTrasporto
FROM Orders
GROUP BY CustomerID;

-- 7) Numero totale di clienti raggruppati per citt� di appartenenza
SELECT City, COUNT(*) AS NumeroClientiPerCitta
FROM Customers
GROUP BY City;


-- 10) Numero di prodotti censiti per ogni categoria
SELECT CategoryName, COUNT(*) AS NumeroProdottiPerCategoria
FROM Categories
JOIN Products ON Categories.CategoryID = Products.CategoryID
GROUP BY CategoryName;

-- 11) Numero totale di ordini raggruppati per paese di spedizione (ShipCountry)
SELECT ShipCountry, COUNT(*) AS NumeroOrdiniPerPaese
FROM Orders
GROUP BY ShipCountry;

-- 12) La media del costo del trasporto raggruppati per paese di spedizione (ShipCountry)
SELECT ShipCountry, AVG(Freight) AS MediaCostoTrasportoPerPaese
FROM Orders
GROUP BY ShipCountry;